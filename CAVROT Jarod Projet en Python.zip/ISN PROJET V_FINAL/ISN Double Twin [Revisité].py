from tkinter import *
from random import *
#import pygame
#from pygame.locals import *
#pygame.init()

#fenetre et canevas

fenetre = Tk()
fenetre.title("Double Twin [Revisité]")

# Images
fond = PhotoImage(file="images/plateau.gif")
bouton_jouer = PhotoImage(file="images/bouton_jouer.gif")
bouton_regles = PhotoImage(file="images/bouton_regles.gif")
bouton_credits = PhotoImage(file="images/bouton_credits.gif")
regles_jeu = PhotoImage(file="images/regles_jeu.gif")
credits = PhotoImage(file="images/credits.gif")
retour = PhotoImage(file="images/croix.gif")
bouton_quitter = PhotoImage(file="images/bouton_quitter.gif")
victoire_bleu = PhotoImage(file="images/victoire_bleu.gif")
victoire_rouge = PhotoImage(file="images/victoire_rouge.gif")
canvas = Canvas(fenetre, width=1280, height=690)
canvas.pack()

# Musique
#pygame.mixer.music.load("sons/NieR_Automata_OST_Intro.ogg")
#pygame.mixer.music.play(999999)



# Variables globales

# Variable pour la carte sélectionnée
Carte = []

# Variable déterminant la couleur du joueur (0 = rouge et 1 = bleu)
joueur = 1

# Variables indiquant si la case est occupée
slot_1 = slot_2 = slot_3 = slot_4 = slot_5 = slot_6 = slot_7 = slot_8 = slot_9 = 0

# Variables indiquant la couleur de la carte dans les slot (0 = rouge, 1 = bleu). Par défaut à bleu
color_slot_1 = color_slot_2 = color_slot_3 = color_slot_4 = color_slot_5 = color_slot_6 = color_slot_7 = color_slot_8 = color_slot_9 = 1

# Variables indiquant quelle carte se trouve dans une case
carte_slot_1 = carte_slot_2 = carte_slot_3 = carte_slot_4 = carte_slot_5 = carte_slot_6 = carte_slot_7 = carte_slot_8 = carte_slot_9 = []

# Variables pour l'inversion de la couleur des cartes
carte_inv_1_2 = carte_inv_1_4 = carte_inv_2_1 = carte_inv_2_3 = carte_inv_2_5 = carte_inv_3_1 = carte_inv_3_6 = carte_inv_4_1 = carte_inv_4_5 = carte_inv_4_7 = 0
carte_inv_5_2 = carte_inv_5_6 = carte_inv_5_8 = carte_inv_5_4 = carte_inv_6_3 = carte_inv_6_9 = carte_inv_6_5 = carte_inv_7_4 = carte_inv_7_8 = carte_inv_8_5 = carte_inv_8_9 = carte_inv_8_7 = carte_inv_9_6 = carte_inv_9_8 = 0

# Liste des cartes et des valeurs
liste_cartes = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]
liste_valeurs = [[3,2,3,2],[4,1,4,1],[1,5,4,5],[4,4,3,4],[4,8,3,5],[7,3,2,3],[4,4,4,3],[9,9,8,9],[4,5,3,3],[5,5,5,5],[6,5,4,5],[4,4,8,4],[2,3,2,3],[6,1,2,1],[3,5,5,7],[3,6,5,6],[7,6,6,6],[5,5,5,10],[5,7,8,5],[6,6,7,6],[6,5,5,9],[7,10,6,7],[10,5,10,5]]

fenetre.resizable(width=False, height=False)

# Affichage du plateau et les boutons
canvas.create_image(640, 345, image=fond)
canvas.create_image(150, 150, image=bouton_jouer, tags="jouer")
canvas.create_image(150, 350, image=bouton_regles, tags="regles")
canvas.create_image(150, 550, image=bouton_credits, tags="credits")
canvas.create_image(1130, 550, image=bouton_quitter, tags="quitter")



# Distribution aléatoire de 5 cartes pour chaque joueur
donne_bleu = sample(liste_cartes,5)
donne_rouge = sample(liste_cartes,5)

# Pour afficher les cartes de la donne du joueur bleu
carte_1_b_s = (PhotoImage(file="cartes_s/carte_bleu_"+str(donne_bleu[0])+".gif"))
carte_2_b_s = (PhotoImage(file="cartes_s/carte_bleu_"+str(donne_bleu[1])+".gif"))
carte_3_b_s = (PhotoImage(file="cartes_s/carte_bleu_"+str(donne_bleu[2])+".gif"))
carte_4_b_s = (PhotoImage(file="cartes_s/carte_bleu_"+str(donne_bleu[3])+".gif"))
carte_5_b_s = (PhotoImage(file="cartes_s/carte_bleu_"+str(donne_bleu[4])+".gif"))


# Pour afficher les cartes jouées du joueur bleu
carte_1_b_l = (PhotoImage(file="cartes_l/carte_bleu_"+str(donne_bleu[0])+".gif"))
carte_2_b_l = (PhotoImage(file="cartes_l/carte_bleu_"+str(donne_bleu[1])+".gif"))
carte_3_b_l = (PhotoImage(file="cartes_l/carte_bleu_"+str(donne_bleu[2])+".gif"))
carte_4_b_l = (PhotoImage(file="cartes_l/carte_bleu_"+str(donne_bleu[3])+".gif"))
carte_5_b_l = (PhotoImage(file="cartes_l/carte_bleu_"+str(donne_bleu[4])+".gif"))


# Pour afficher les cartes de la donne du joueur rouge
carte_1_r_s = (PhotoImage(file="cartes_s/carte_rouge_"+str(donne_rouge[0])+".gif"))
carte_2_r_s = (PhotoImage(file="cartes_s/carte_rouge_"+str(donne_rouge[1])+".gif"))
carte_3_r_s = (PhotoImage(file="cartes_s/carte_rouge_"+str(donne_rouge[2])+".gif"))
carte_4_r_s = (PhotoImage(file="cartes_s/carte_rouge_"+str(donne_rouge[3])+".gif"))
carte_5_r_s = (PhotoImage(file="cartes_s/carte_rouge_"+str(donne_rouge[4])+".gif"))

# Pour afficher les cartes jouées du joueur rouge
carte_1_r_l = (PhotoImage(file="cartes_l/carte_rouge_"+str(donne_rouge[0])+".gif"))
carte_2_r_l = (PhotoImage(file="cartes_l/carte_rouge_"+str(donne_rouge[1])+".gif"))
carte_3_r_l = (PhotoImage(file="cartes_l/carte_rouge_"+str(donne_rouge[2])+".gif"))
carte_4_r_l = (PhotoImage(file="cartes_l/carte_rouge_"+str(donne_rouge[3])+".gif"))
carte_5_r_l = (PhotoImage(file="cartes_l/carte_rouge_"+str(donne_rouge[4])+".gif"))

def affichage(event) :

    # Coordonnées du clique
    val_x = (event.x)
    val_y = (event.y)

    #Quitter le jeu
    if val_x > 1030 and val_x < 1230 and val_y > 500 and val_y < 600 :
        pygame.mixer.music.fadeout(1500)
        fenetre.destroy()
        

    #Affichage des règles
    if val_x > 50 and val_x < 250 and val_y > 300 and val_y < 400 :
        
        canvas.create_image (640, 345, image=regles_jeu, tags="regles2")
        canvas.create_image (935, 227, image=retour, tags ="retour")

    if val_x > 925 and val_x < 950 and val_y > 215 and val_y < 240 :

        canvas.delete("regles2")
        canvas.delete("retour")

    #Affichage des crédits
    if val_x > 50 and val_x < 250 and val_y > 500 and val_y < 600 :

        canvas.create_image (640, 345, image=credits, tags="crédits2")
        canvas.create_image (935, 227, image=retour, tags ="retour")

    if val_x > 925 and val_x < 950 and val_y > 215 and val_y < 240 :

        canvas.delete("crédits2")
        canvas.delete("retour")
    

    # Pour lancer le jeu
    if val_x > 0 and val_x < 300 and val_y > 100 and val_y < 200 :
        

        

        # On efface les boutons
        canvas.delete("jouer")
        canvas.delete("regles")
        canvas.delete("regles2")
        canvas.delete("retour")
        canvas.delete("credits")
        canvas.delete("quitter")
        canvas.delete("crédits2")

        # Musique
        #pygame.mixer.music.fadeout(1500)
        #pygame.mixer.music.load("sons/No_Game_No_Life_All_of_you_is_all_of_me_OST.ogg")
        #pygame.mixer.music.play(999999)
        


        # Affichage de la donne bleu
        canvas.create_image(260, 80, image=carte_1_b_s, tags="b1")
        canvas.create_image(260, 200, image=carte_2_b_s, tags="b2")
        canvas.create_image(260, 320, image=carte_3_b_s, tags="b3")
        canvas.create_image(260, 440, image=carte_4_b_s, tags="b4")
        canvas.create_image(260, 560, image=carte_5_b_s, tags="b5")

        # Affichage de la donne rouge
        canvas.create_image(1030, 80, image=carte_1_r_s, tags="r1")
        canvas.create_image(1030, 200, image=carte_2_r_s, tags="r2")
        canvas.create_image(1030, 320, image=carte_3_r_s, tags="r3")
        canvas.create_image(1030, 440, image=carte_4_r_s, tags="r4")
        canvas.create_image(1030, 560, image=carte_5_r_s, tags="r5")

        fenetre.bind("<Button-1>",jouer)


def jouer(event):
    global joueur, Carte
    global slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9
    global carte_inv_1_2, carte_inv_1_4, carte_inv_2_1, carte_inv_2_3, carte_inv_2_5, carte_inv_3_2, carte_inv_3_6
    global carte_inv_4_1, carte_inv_4_5, carte_inv_4_7, carte_inv_5_2, carte_inv_5_6, carte_inv_5_8, carte_inv_5_4
    global carte_inv_6_3, carte_inv_6_9, carte_inv_6_5, carte_inv_7_4, carte_inv_7_8, carte_inv_8_5, carte_inv_8_9
    global carte_inv_8_7, carte_inv_9_6, carte_inv_9_8
    global carte_slot_1, carte_slot_2, carte_slot_3, carte_slot_4, carte_slot_5, carte_slot_6, carte_slot_7, carte_slot_8, carte_slot_9
    global color_slot_1, color_slot_2, color_slot_3, color_slot_4, color_slot_5, color_slot_6, color_slot_7, color_slot_8, color_slot_9


    # Coordonnées du clique
    val_x = (event.x)
    val_y = (event.y)

    if joueur == 1:
        # On choisit la première carte bleu
        if val_x >= 220 and val_x <= 300 and val_y >= 30 and val_y <= 130:
            Carte = [carte_1_b_l, donne_bleu[0]]
            canvas.delete('b1')


        # On choisit la deuxieme carte bleu
        if val_x >= 220 and val_x <= 300 and val_y >= 150 and val_y <= 250:
            Carte = [carte_2_b_l, donne_bleu[1]]
            canvas.delete('b2')

        # On choisit la troisième carte bleu
        if val_x >= 220 and val_x <= 300 and val_y >= 270 and val_y <= 370:
            Carte = [carte_3_b_l, donne_bleu[2]]
            canvas.delete('b3')

        # On choisit la quatrième carte bleu
        if val_x >= 220 and val_x <= 300 and val_y >= 390 and val_y <= 490:
            Carte = [carte_4_b_l, donne_bleu[3]]
            canvas.delete('b4')

        # On choisit la cinquième carte bleu
        if val_x >= 220 and val_x <= 300 and val_y >= 510 and val_y <= 610:
            Carte = [carte_5_b_l, donne_bleu[4]]
            canvas.delete('b5')
    else :
        # On choisit la première carte rouge
        if val_x >= 990 and val_x <= 1070 and val_y >= 30 and val_y <= 130:
            Carte = [carte_1_r_l, donne_rouge[0]]
            canvas.delete('r1')

        # On choisit la deuxieme carte rouge
        if val_x >= 990 and val_x <= 1070 and val_y >= 150 and val_y <= 250:
            Carte = [carte_2_r_l, donne_rouge[1]]
            canvas.delete('r2')

        # On choisit la troisième carte rouge
        if val_x >= 990 and val_x <= 1070 and val_y >= 270 and val_y <= 370:
            Carte = [carte_3_r_l, donne_rouge[2]]
            canvas.delete('r3')

        # On choisit la quatrième carte rouge
        if val_x >= 990 and val_x <= 1070 and val_y >= 390 and val_y <= 490:
            Carte = [carte_4_r_l, donne_rouge[3]]
            canvas.delete('r4')

        # On choisit la cinquième carte rouge
        if val_x >= 990 and val_x <= 1070 and val_y >= 510 and val_y <= 610:
            Carte = [carte_5_r_l, donne_rouge[4]]
            canvas.delete('r5')

    # Case 1
    if val_x >= 389 and val_x <= 562 and val_y >= 26 and val_y <= 238 :     # On vérifie si le clique est dans le slot   
        if slot_1 == 0 and Carte:                                           # Si le slot est libre on affiche la carte et on récupère ses données
            canvas.create_image(476, 132, image = Carte[0])
            carte_slot_1 = [Carte[1], liste_valeurs[Carte[1]][0],liste_valeurs[Carte[1]][1],liste_valeurs[Carte[1]][2],
                            liste_valeurs[Carte[1]][3]]
            # Comparaison avec slot 2 : valeur droite slot 1 et valeur gauche slot 2
            if slot_2 == 1:
                if carte_slot_1[2] > carte_slot_2[4]:
                    if joueur == 1:
                        carte_inv_1_2 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_2[0]) + ".gif"))
                        color_slot_2 = 1
                    else:
                        carte_inv_1_2 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_2[0]) + ".gif"))
                        color_slot_2 = 0
                    canvas.create_image(652, 132, image=carte_inv_1_2)
            # Comparaison avec slot 2 : valeur basse slot 1 et valeur haute slot 4
            if slot_4 == 1:
                if carte_slot_1[3] > carte_slot_4[1]:
                    if joueur == 1:
                        carte_inv_1_4 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_4[0]) + ".gif"))
                        color_slot_4 = 1
                    else:
                        carte_inv_1_4 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_4[0]) + ".gif"))
                        color_slot_4 = 0
                    canvas.create_image(476, 342, image=carte_inv_1_4)
                    
            if joueur == 1 :                                                  # si le joueur est bleu on passe le tour au joueur rouge
                joueur = 0                                                    
                color_slot_1 = 1
            else :                                                            # sinon si le joueur est rouge on passe le tour au joueur bleu
                joueur = 1                                                    
                color_slot_1 = 0
            slot_1 = 1                                                       # On bloque la possibilité de reposer une carte sur le slot
            Carte = []                                                       # On vide la carte qui est en mémoire

    #Case 2
    if val_x >= 562 and val_x <= 735 and val_y >= 26 and val_y <= 238 :
        if slot_2 == 0 and Carte:
            canvas.create_image(652, 132, image = Carte[0])
            carte_slot_2 = [Carte[1], liste_valeurs[Carte[1]][0],liste_valeurs[Carte[1]][1],liste_valeurs[Carte[1]][2],
                            liste_valeurs[Carte[1]][3]]
            # Comparaison avec slot 1 : valeur droite slot 1 et valeur gauche slot 2
            if slot_1 == 1:
                if carte_slot_2[4] > carte_slot_1[2]:
                    if joueur == 1:
                        carte_inv_2_1 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_1[0]) + ".gif"))
                        color_slot_1 = 1
                    else:
                        carte_inv_2_1 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_1[0]) + ".gif"))
                        color_slot_1 = 0
                    canvas.create_image(476, 132, image=carte_inv_2_1)
                    
            # Comparaison avec slot 3 : valeur droite slot 2 et valeur gauche slot 3
            if slot_3 == 1:
                if carte_slot_2[2] > carte_slot_3[4]:
                    if joueur == 1:
                        carte_inv_2_3 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_3[0]) + ".gif"))
                        color_slot_3 = 1
                    else:
                        carte_inv_2_3 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_3[0]) + ".gif"))
                        color_slot_3 = 0
                    canvas.create_image(826, 132, image=carte_inv_2_3)
            # Comparaison avec slot 5 : valeur basse slot 2 et valeur haute slot 5
            if slot_5 == 1:
                if carte_slot_2[3] > carte_slot_5[1]:
                    if joueur == 1:
                        carte_inv_2_5 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_5[0]) + ".gif"))
                        color_slot_5 = 1
                    else:
                        carte_inv_2_5 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_5[0]) + ".gif"))
                        color_slot_5 = 0
                    canvas.create_image(652, 342, image=carte_inv_2_5)
            if joueur == 1 :
                joueur = 0
                color_slot_2 = 1
            else :
                joueur = 1
                color_slot_2 = 0
            slot_2 = 1
            Carte = []

    #Case 3
    if val_x >= 735 and val_x <= 908 and val_y >= 26 and val_y <= 238 :
        if slot_3 == 0 and Carte:
            canvas.create_image(826, 132, image = Carte[0])
            carte_slot_3 = [Carte[1], liste_valeurs[Carte[1]][0],liste_valeurs[Carte[1]][1],liste_valeurs[Carte[1]][2],
                            liste_valeurs[Carte[1]][3]]
            # Comparaison avec slot 2 : valeur droite slot 2 et valeur gauche slot 3
            if slot_2 == 1:
                if carte_slot_3[4] > carte_slot_2[2]:
                    if joueur == 1:
                        carte_inv_3_2 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_2[0]) + ".gif"))
                        color_slot_2 = 1
                    else:
                        carte_inv_3_2 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_2[0]) + ".gif"))
                        color_slot_2 = 0
                    canvas.create_image(652, 132, image=carte_inv_3_2)
            # Comparaison avec slot 6 : valeur basse slot 3 et valeur haute slot 6
            if slot_6 == 1:
                if carte_slot_3[3] > carte_slot_6[1]:
                    if joueur == 1:
                        carte_inv_3_6 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_6[0]) + ".gif"))
                        color_slot_6 = 1
                    else:
                        carte_inv_3_6 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_6[0]) + ".gif"))
                        color_slot_6= 0
                    canvas.create_image(826, 342, image=carte_inv_3_6)
            if joueur == 1 :
                joueur = 0
                color_slot_3 = 1
            else :
                joueur = 1
                color_slot_3 = 0
            slot_3 = 1
            Carte = []

    #Case 4
    if val_x >= 389 and val_x <= 562 and val_y >= 236 and val_y <= 446 :
        if slot_4 == 0 :
            canvas.create_image(476, 342, image = Carte[0])
            carte_slot_4 = [Carte[1], liste_valeurs[Carte[1]][0],liste_valeurs[Carte[1]][1],liste_valeurs[Carte[1]][2],
                            liste_valeurs[Carte[1]][3]]
            # Comparaison avec slot 1 : valeur basse slot 1 et valeur haute slot 4
            if slot_1 == 1:
                if carte_slot_4[1] > carte_slot_1[3]:
                    if joueur == 1:
                        carte_inv_4_1 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_1[0]) + ".gif"))
                        color_slot_1 = 1
                    else:
                        carte_inv_4_1 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_1[0]) + ".gif"))
                        color_slot_1 = 0
                    canvas.create_image(476, 132, image=carte_inv_4_1)
            # Comparaison avec slot 5 : valeur droite slot 4 et valeur gauche slot 5
            if slot_5 == 1:
                if carte_slot_4[2] > carte_slot_5[4]:
                    if joueur == 1:
                        carte_inv_4_5 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_5[0]) + ".gif"))
                        color_slot_5 = 1
                    else:
                        carte_inv_4_5 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_5[0]) + ".gif"))
                        color_slot_5 = 0
                    canvas.create_image(652, 342, image=carte_inv_4_5)
            # Comparaison avec slot 7 : valeur basse slot 4 et valeur haute slot 7
            if slot_7 == 1:
                if carte_slot_4[3] > carte_slot_7[1]:
                    if joueur == 1:
                        carte_inv_4_7 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_7[0]) + ".gif"))
                        color_slot_7 = 1
                    else:
                        carte_inv_4_7 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_7[0]) + ".gif"))
                        color_slot_7 = 0
                    canvas.create_image(476, 552, image=carte_inv_4_7)
            if joueur == 1 :
                joueur = 0
                color_slot_4 = 1
            else :
                joueur = 1
                color_slot_4 = 0
            slot_4 = 1
            Carte = []

    #Case 5
    if val_x >= 562 and val_x <= 735 and val_y >= 236 and val_y <= 446 :
        if slot_5 == 0 :
            canvas.create_image(652, 342, image = Carte[0])
            carte_slot_5 = [Carte[1], liste_valeurs[Carte[1]][0],liste_valeurs[Carte[1]][1],liste_valeurs[Carte[1]][2],liste_valeurs[Carte[1]][3]]
            # Comparaison avec slot 2 : valeur basse slot 2 et valeur haute slot 5
            if slot_2 == 1:
                if carte_slot_5[1] > carte_slot_2[3]:
                    if joueur == 1:
                        carte_inv_5_2 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_2[0]) + ".gif"))
                        color_slot_2 = 1
                    else:
                        carte_inv_5_2 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_2[0]) + ".gif"))
                        color_slot_2 = 0
                    canvas.create_image(652, 132, image=carte_inv_5_2)
            # Comparaison avec slot 6 : valeur droite slot 5 et valeur gauche slot 6
            if slot_6 == 1:
                if carte_slot_5[2] > carte_slot_6[4]:
                    if joueur == 1:
                        carte_inv_5_6 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_6[0]) + ".gif"))
                        color_slot_6 = 1
                    else:
                        carte_inv_5_6 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_6[0]) + ".gif"))
                        color_slot_6 = 0
                    canvas.create_image(826, 342, image=carte_inv_5_6)
            # Comparaison avec slot 8 : valeur basse slot 5 et valeur haute slot 8
            if slot_8 == 1:
                if carte_slot_5[3] > carte_slot_8[1]:
                    if joueur == 1:
                        carte_inv_5_8 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_8[0]) + ".gif"))
                        color_slot_8 = 1
                    else:
                        carte_inv_5_8 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_8[0]) + ".gif"))
                        color_slot_8 = 0
                    canvas.create_image(652, 552, image=carte_inv_5_8)
            # Comparaison avec slot 4 : valeur droite slot 4 et valeur gauche slot 5
            if slot_4 == 1:
                if carte_slot_5[4] > carte_slot_4[2]:
                    if joueur == 1:
                        carte_inv_5_4 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_4[0]) + ".gif"))
                        color_slot_4 = 1
                    else:
                        carte_inv_5_4 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_4[0]) + ".gif"))
                        color_slot_4 = 0
                    canvas.create_image(476, 342, image=carte_inv_5_4)
            if joueur == 1 :
                joueur = 0
                color_slot_5 = 1
            else :
                joueur = 1
                color_slot_5 = 0
            slot_5 = 1
            Carte = []

    #Case 6
    if val_x >= 735 and val_x <= 908 and val_y >= 236 and val_y <= 446 :
        if slot_6 == 0 :
            canvas.create_image(826, 342, image = Carte[0])
            carte_slot_6 = [Carte[1], liste_valeurs[Carte[1]][0], liste_valeurs[Carte[1]][1],
                            liste_valeurs[Carte[1]][2], liste_valeurs[Carte[1]][3]]
            # Comparaison avec slot 3 : valeur basse slot 3 et valeur haute slot 6
            if slot_3 == 1:
                if carte_slot_6[1] > carte_slot_3[3]:
                    if joueur == 1:
                        carte_inv_6_3 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_3[0]) + ".gif"))
                        color_slot_3 = 1
                    else:
                        carte_inv_6_3 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_3[0]) + ".gif"))
                        color_slot_3 = 0
                    canvas.create_image(826, 132, image=carte_inv_6_3)
            # Comparaison avec slot 9 : valeur basse slot 6 et valeur haute slot 9
            if slot_9 == 1:
                if carte_slot_6[3] > carte_slot_9[1]:
                    if joueur == 1:
                        carte_inv_6_9 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_9[0]) + ".gif"))
                        color_slot_9 = 1
                    else:
                        carte_inv_6_9 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_9[0]) + ".gif"))
                        color_slot_9 = 0
                    canvas.create_image(826, 552, image=carte_inv_6_9)
            # Comparaison avec slot 5 : valeur droite slot 5 et valeur gauche slot 6
            if slot_5 == 1:
                if carte_slot_6[4] > carte_slot_5[2]:
                    if joueur == 1:
                        carte_inv_6_5 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_5[0]) + ".gif"))
                        color_slot_5 = 1
                    else:
                        carte_inv_6_5 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_5[0]) + ".gif"))
                        color_slot_5 = 0
                    canvas.create_image(652, 342, image=carte_inv_6_5)
            if joueur == 1 :
                joueur = 0
                color_slot_6 = 1
            else :
                joueur = 1
                color_slot_6 = 0
            slot_6 = 1
            Carte = []

    #Case 7
    if val_x >= 389 and val_x <= 562 and val_y >= 446 and val_y <= 656 :
        if slot_7 == 0 :
            canvas.create_image(476, 552, image = Carte[0])
            carte_slot_7 = [Carte[1], liste_valeurs[Carte[1]][0], liste_valeurs[Carte[1]][1],
                            liste_valeurs[Carte[1]][2], liste_valeurs[Carte[1]][3]]
            # Comparaison avec slot 4 : valeur basse slot 4 et valeur haute slot 7
            if slot_4 == 1:
                if carte_slot_7[1] > carte_slot_4[3]:
                    if joueur == 1:
                        carte_inv_7_4 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_4[0]) + ".gif"))
                        color_slot_4 = 1
                    else:
                        carte_inv_7_4 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_4[0]) + ".gif"))
                        color_slot_4 = 0
                    canvas.create_image(476, 342, image=carte_inv_7_4)
            # Comparaison avec slot 8 : valeur droite slot 7 et valeur gauche slot 8
            if slot_8 == 1:
                if carte_slot_7[2] > carte_slot_8[4]:
                    if joueur == 1:
                        carte_inv_7_8 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_8[0]) + ".gif"))
                        color_slot_8 = 1
                    else:
                        carte_inv_7_8 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_8[0]) + ".gif"))
                        color_slot_8 = 0
                    canvas.create_image(652, 552, image=carte_inv_7_8)
            if joueur == 1 :
                joueur = 0
                color_slot_7 = 1
            else :
                joueur = 1
                color_slot_7 = 0
            slot_7 = 1
            Carte = []

    #Case 8
    if val_x >= 562 and val_x <= 735 and val_y >= 446 and val_y <= 656 :
        if slot_8 == 0 :
            canvas.create_image(652, 552, image = Carte[0])
            carte_slot_8 = [Carte[1], liste_valeurs[Carte[1]][0],liste_valeurs[Carte[1]][1],liste_valeurs[Carte[1]][2],liste_valeurs[Carte[1]][3]]
            # Comparaison avec slot 5 : valeur basse slot 5 et valeur haute slot 8
            if slot_5 == 1:
                if carte_slot_8[1] > carte_slot_5[3]:
                    if joueur == 1:
                        carte_inv_8_5 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_5[0]) + ".gif"))
                        color_slot_5 = 1
                    else:
                        carte_inv_8_5 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_5[0]) + ".gif"))
                        color_slot_5 = 0
                    canvas.create_image(652, 342, image=carte_inv_8_5)
            # Comparaison avec slot 9 : valeur droite slot 8 et valeur gauche slot 9
            if slot_9 == 1:
                if carte_slot_8[2] > carte_slot_9[4]:
                    if joueur == 1:
                        carte_inv_8_9 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_9[0]) + ".gif"))
                        color_slot_9 = 1
                    else:
                        carte_inv_8_9 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_9[0]) + ".gif"))
                        color_slot_9 = 0
                    canvas.create_image(826, 552, image=carte_inv_8_9)
            # Comparaison avec slot 7 : valeur droite slot 7 et valeur gauche slot 8
            if slot_7 == 1:
                if carte_slot_8[4] > carte_slot_7[2]:
                    if joueur == 1:
                        carte_inv_8_7 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_7[0]) + ".gif"))
                        color_slot_7 = 1
                    else:
                        carte_inv_8_7 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_7[0]) + ".gif"))
                        color_slot_7 = 0
                    canvas.create_image(476, 552, image=carte_inv_8_7)
            if joueur == 1 :
                joueur = 0
                color_slot_8 = 1
            else :
                joueur = 1
                color_slot_8 = 0
            slot_8 = 1
            Carte = []


    #Case 9
    if val_x >= 735 and val_x <= 908 and val_y >= 446 and val_y <= 656 :
        if slot_9 == 0 :
            canvas.create_image(826, 552, image = Carte[0])
            carte_slot_9 = [Carte[1], liste_valeurs[Carte[1]][0],liste_valeurs[Carte[1]][1],liste_valeurs[Carte[1]][2],liste_valeurs[Carte[1]][3]]
            # Comparaison avec slot 6 : valeur basse slot 6 et valeur haute slot 9
            if slot_6 == 1:
                if carte_slot_9[1] > carte_slot_6[3]:
                    if joueur == 1:
                        carte_inv_9_6 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_6[0]) + ".gif"))
                        color_slot_6 = 1
                    else:
                        carte_inv_9_6 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_6[0]) + ".gif"))
                        color_slot_6 = 0
                    canvas.create_image(826, 342, image=carte_inv_9_6)
            # Comparaison avec slot 8 : valeur droite slot 8 et valeur gauche slot 9
            if slot_8 == 1:
                if carte_slot_9[4] > carte_slot_8[2]:
                    if joueur == 1:
                        carte_inv_9_8 = (PhotoImage(file="cartes_l/carte_bleu_" + str(carte_slot_8[0]) + ".gif"))
                        color_slot_8 = 1
                    else:
                        carte_inv_9_8 = (PhotoImage(file="cartes_l/carte_rouge_" + str(carte_slot_8[0]) + ".gif"))
                        color_slot_8 = 0
                    canvas.create_image(652, 552, image=carte_inv_9_8)
            if joueur == 1 :
                joueur = 0
                color_slot_9 = 1
            else :
                joueur = 1
                color_slot_9 = 0
            slot_9 = 1
            Carte = []

    nb_color = color_slot_1 + color_slot_2 + color_slot_3 + color_slot_4 + color_slot_5 + color_slot_6 + color_slot_7 + color_slot_8 + color_slot_9
    nb_slot = slot_1 + slot_2 + slot_3 + slot_4 + slot_5 + slot_6 + slot_7 + slot_8 + slot_9

    if nb_slot == 9 :
        if nb_color> 4 :
            val_x = (event.x)
            val_y = (event.y)
            canvas.create_image(650, 345, image=victoire_bleu)
            canvas.create_image(650, 475, image=bouton_quitter, tags="quitter")
            if val_x > 550 and val_x < 750 and val_y > 425 and val_y < 525 :
                fenetre.destroy()
                #pygame.mixer.music.fadeout(1500)
        else :
            canvas.create_image(650, 345, image=victoire_rouge)
            canvas.create_image(650, 475, image=bouton_quitter, tags="quitter")
            if val_x > 550 and val_x < 750 and val_y > 425 and val_y < 525 :
                fenetre.destroy()
                #pygame.mixer.music.fadeout(1500)



fenetre.bind("<Button-1>",affichage)

fenetre.mainloop()
